#pragma once
// funciones.h
#ifndef FUNCIONES_H  // Directiva de inclusi�n m�ltiple
#define FUNCIONES_H

// Declaraciones de funciones
void saludar();        // Funci�n que imprime un saludo
int sumar(int a, int b); // Funci�n que suma dos n�meros y retorna el resultado

#endif // FUNCIONES_H
