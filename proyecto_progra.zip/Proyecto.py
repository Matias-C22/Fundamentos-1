import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from PIL import Image, ImageTk
import json


class Mostrar:
    def __init__(self, main_program_class):
        self.main_program_class = main_program_class
        self.ventana = tk.Tk()
        self.ventana.title("Filtro por Categorías")
        self.ventana.geometry("1500x1000")  # Window size

        # Load store data from the JSON file
        self.store_data = self.load_store_data()

        # Extract categories dynamically
        self.categories = [
            "Ropa", "Electrodomésticos", "Gimnasios", "Entretenimiento", 
            "Accesorios", "Zapaterías", "Peluquerías", "Supermercados", 
            "Institutos", "Catering"
        ]

        # Load background image
        self.fondo_imagen = Image.open("fondo.png")
        self.fondo_imagen = self.fondo_imagen.resize((1400, 900), Image.Resampling.LANCZOS)
        self.fondo_imagen_tk = ImageTk.PhotoImage(self.fondo_imagen)

        # Create a Canvas to place the background image
        self.canvas = tk.Canvas(self.ventana, width=800, height=1500)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.create_image(0, 0, image=self.fondo_imagen_tk, anchor="nw")  # Ensure the image stays referenced

        # Set up the category selection
        self.categoria_var = tk.StringVar()
        self.categoria_var.set(self.categories[0])  # Default category

        # Instructions label
        self.instrucciones_label = tk.Label(
            self.ventana, text="Selecciona una categoría para filtrar las tiendas disponibles:",
            font=("Helvetica", 30, "bold"), fg="white", bg="black",
            relief="solid", padx=20, pady=20, borderwidth=2
        )
        self.instrucciones_label.place(x=50, y=30)

        # Dropdown menu (combo box) for category selection
        self.categoria_menu = ttk.OptionMenu(self.ventana, self.categoria_var, *self.categories)
        self.categoria_menu.place(x=500, y=100)

        # Button to show products for the selected category
        self.boton_mostrar = tk.Button(
            self.ventana, text="Mostrar tiendas",
            font=("Helvetica", 20, "bold"), bg="yellow", command=self.mostrar_productos
        )
        self.boton_mostrar.place(x=400, y=180)

        self.boton_salir = tk.Button(
            self.ventana, text="Salir",
            font=("Helvetica", 20, "bold"), bg="yellow", command=self.salir_tiendas)
        self.boton_salir.place(x=1200, y=600)

        # Listbox to display products
        self.productos_lista = tk.Listbox(
            self.ventana, width=40, height=10, bg="white", bd=0, font=("Arial", 12)
        )
        self.productos_lista.place(x=400, y=250)

        # Scrollbar for the product list
        self.scrollbar = tk.Scrollbar(self.ventana, orient="vertical", command=self.productos_lista.yview)
        self.productos_lista.config(yscrollcommand=self.scrollbar.set)
        self.scrollbar.place(x=760, y=250, height=200)

    def load_store_data(self):
        """
        Load store data from the JSON file.
        """
        try:
            with open("tiendas.json", "r", encoding="utf-8") as file:
                return json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            messagebox.showerror("Error", "El archivo 'tiendas.json' no se encontró o tiene un formato inválido.")
            return []

    def mostrar_productos(self):
        """
        Show stores in the selected category.
        """
        categoria_seleccionada = self.categoria_var.get()
        if not categoria_seleccionada:
            messagebox.showerror("Error", "No se seleccionó ninguna categoría válida.")
            return

        # Filter stores based on the selected category
        tiendas_categoria = [store['nombre'] for store in self.store_data if store['categoria'] == categoria_seleccionada]

        # Clear the product list
        self.productos_lista.delete(0, tk.END)

        if tiendas_categoria:
            # Insert stores for the selected category
            for tienda in tiendas_categoria:
                self.productos_lista.insert(tk.END, tienda)
        else:
            # Display a message if no stores are found
            self.productos_lista.insert(tk.END, "No hay tiendas disponibles en esta categoría.")

    def salir_tiendas(self):
        """
        Exit the current window and return to the main program.
        """
        for widget in self.ventana.winfo_children():
            widget.destroy()
        self.ventana.destroy()
        self.main_program_class()

    def iniciar(self):
        """
        Start the main Tkinter loop.
        """
        self.ventana.mainloop()


# Check if the script is being run directly
if __name__ == "__main__":
    app = Mostrar(lambda: print("Main Program Placeholder"))
    app.iniciar()
