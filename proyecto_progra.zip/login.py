import json
from tkinter import *
from tkinter import messagebox
from PIL import Image, ImageTk
from membresia_gratuita import MenuP


class app:
    def __init__(self):
        self.ventana = Tk()
        self.ventana.title("Circlify")
        self.ventana.iconbitmap("circlify.ico")
        self.ventana.geometry("600x800")

        fondo = "black"

        # Load existing users from JSON if it exists
        self.usuarios = self.load_from_json()

        self.ventana_login(fondo)

    def load_from_json(self):
        """Load existing users from a JSON file."""
        try:
            with open("usuarios.json", "r") as file:
                return json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            # Return an empty dictionary if file doesn't exist or is corrupted
            return {}

    def save_to_json(self):
        """Save the current user data to a JSON file."""
        with open("usuarios.json", "w") as file:
            json.dump(self.usuarios, file, indent=4)

    def ventana_login(self, fondo):
        for widget in self.ventana.winfo_children():
            widget.destroy()

        self.marco_sup = Frame(self.ventana)
        self.marco_sup.config(bg=fondo)
        self.marco_sup.pack(fill="both", expand=True)

        self.marco_inf = Frame(self.ventana)
        self.marco_inf.config(bg=fondo)
        self.marco_inf.pack(fill="both", expand=True)

        self.marco_inf.columnconfigure(0, weight=1)
        self.marco_inf.columnconfigure(1, weight=1)

        self.titulo = Label(self.marco_sup,
                            text="Ingrese sus datos para acceder a su cuenta",
                            font=("Calisto MT", 20, "bold"),
                            bg=fondo,
                            fg="white")
        self.titulo.pack(side="top", pady=10)

        self.img = Image.open("circlify.png")
        self.img = self.img.resize((200, 165))
        self.render = ImageTk.PhotoImage(self.img)
        self.fondo = Label(self.marco_sup, image=self.render, bg=fondo)
        self.fondo.pack(expand=True, fill="both", side="top")

        self.usuariot_log = Label(self.marco_inf, text="Usuario: ", bg="black", fg="white", font=("Arial", 10))
        self.usuariot_log.grid(row=0, column=0, sticky="e", padx=10)

        self.usuarioe_log = Entry(self.marco_inf,
                                  relief="flat",
                                  highlightbackground="gray",
                                  highlightcolor="red",
                                  highlightthickness=3,
                                  bd=4)
        self.usuarioe_log.grid(row=0, column=1, padx=20, pady=20, sticky="w")

        self.contrasenat_log = Label(self.marco_inf, text="contrasena: ", bg="black", fg="white", font=("Arial", 10))
        self.contrasenat_log.grid(row=1, column=0, sticky="e")

        self.contrasenae_log = Entry(self.marco_inf,
                                     relief="flat",
                                     highlightbackground="gray",
                                     highlightcolor="red",
                                     highlightthickness=3,
                                     bd=4, show="*")
        self.contrasenae_log.grid(row=1, column=1, padx=20, pady=20, sticky="w")

        self.boton_log = Button(self.marco_inf,
                                text="Login",
                                width=16,
                                font=("Arial", 12),
                                command=self.login)
        self.boton_log.grid(row=2, column=0, columnspan=2, pady=25)

        self.registro = Label(self.marco_inf,
                              text="Si no tiene cuenta, haga click en Sign Up",
                              font=("Calisto MT", 10, "bold"),
                              bg=fondo,
                              fg="white")
        self.registro.grid(row=3, column=0, columnspan=2, pady=10)

        self.boton_reg = Button(self.marco_inf,
                                text="Sign Up",
                                width=16,
                                font=("Arial", 12),
                                command=lambda: self.ventana_registro(fondo))
        self.boton_reg.grid(row=4, column=0, columnspan=2, pady=25)

    def ventana_registro(self, fondo):
        for widget in self.ventana.winfo_children():
            widget.destroy()

        self.marco_sup = Frame(self.ventana)
        self.marco_sup.config(bg=fondo)
        self.marco_sup.pack(fill="both", expand=True)

        self.marco_inf = Frame(self.ventana)
        self.marco_inf.config(bg=fondo)
        self.marco_inf.pack(fill="both", expand=True)

        self.marco_inf.columnconfigure(0, weight=1)
        self.marco_inf.columnconfigure(1, weight=1)

        self.titulo = Label(self.marco_sup,
                            text="Ingrese sus datos para crear una cuenta",
                            font=("Calisto MT", 20, "bold"),
                            bg=fondo,
                            fg="white")
        self.titulo.pack(side="top", pady=10)

        self.img = Image.open("circlify.png")
        self.img = self.img.resize((200, 165))
        self.render = ImageTk.PhotoImage(self.img)
        self.fondo = Label(self.marco_sup, image=self.render, bg=fondo)
        self.fondo.pack(expand=True, fill="both", side="top")

        self.usuariot_reg = Label(self.marco_inf, text="Usuario: ", bg="black", fg="white", font=("Arial", 10))
        self.usuariot_reg.grid(row=0, column=0, sticky="e", padx=10)

        self.usuarioe_reg = Entry(self.marco_inf,
                                  relief="flat",
                                  highlightbackground="gray",
                                  highlightcolor="red",
                                  highlightthickness=3,
                                  bd=4)
        self.usuarioe_reg.grid(row=0, column=1, padx=20, pady=20, sticky="w")

        self.contrasenat_reg = Label(self.marco_inf, text="contrasena: ", bg="black", fg="white", font=("Arial", 10))
        self.contrasenat_reg.grid(row=1, column=0, sticky="e")

        self.contrasenae_reg = Entry(self.marco_inf,
                                     relief="flat",
                                     highlightbackground="gray",
                                     highlightcolor="red",
                                     highlightthickness=3,
                                     bd=4, show="*")
        self.contrasenae_reg.grid(row=1, column=1, padx=20, pady=20, sticky="w")

        self.contrat_confirm_reg = Label(self.marco_inf, text="Confirmar contrasena: ", bg="black", fg="white", font=("Arial", 10))
        self.contrat_confirm_reg.grid(row=2, column=0, sticky="e")

        self.contrae_confirm_reg = Entry(self.marco_inf,
                                         relief="flat",
                                         highlightbackground="gray",
                                         highlightcolor="red",
                                         highlightthickness=3,
                                         bd=4, show="*")
        self.contrae_confirm_reg.grid(row=2, column=1, padx=20, pady=20, sticky="w")

        self.boton_log = Button(self.marco_inf,
                                text="Sign Up",
                                width=16,
                                font=("Arial", 12),
                                command=self.sign_up)
        self.boton_log.grid(row=3, column=0, columnspan=2, pady=25)

    def login(self):
        nombre = self.usuarioe_log.get()
        contra = self.contrasenae_log.get()

        if nombre in self.usuarios and self.usuarios[nombre]["password"] == contra:
            messagebox.showinfo("Acceso correcto", "A ingresado a su cuenta")

            self.ventana.destroy()
            MenuP()
            
            
        else:
            messagebox.showerror("Acceso incorrecto", "Usuario o contrasena incorrecta")

    def sign_up(self):
        nombre = self.usuarioe_reg.get()
        contra = self.contrasenae_reg.get()
        confirm_contra = self.contrae_confirm_reg.get()

        if nombre in self.usuarios:
            messagebox.showerror("Registro incorrecto", "El usuario ya existe")
        elif contra != confirm_contra:
            messagebox.showerror("Registro incorrecto", "Las contrasenas no son iguales")
        elif not nombre or not contra:
            messagebox.showerror("Registro incorrecto", "Rellene todas las casillas")
        else:
            self.usuarios[nombre] = {"password": contra, "membresia": "gratis"}
            messagebox.showinfo("Registro correcto", "Cuenta creada exitosamente")
            self.save_to_json()  
            self.ventana_login("black")


if __name__ == "__main__":
    application = app()
    application.ventana.mainloop()
