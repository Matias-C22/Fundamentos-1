#-- coding: iso-8859-15 --

import tkinter as tk
from tkinter import messagebox

class AsistenteVirtual:
    def __init__(self, main_program_class):
        self.main_program_class = main_program_class 
        self.root = tk.Tk()
        self.root.title("Asistente Virtual de Atenci�n al Cliente")
        self.root.geometry("1900x1000")
        self.root.config(bg="black")

        # Welcome Label
        self.label_welcome = tk.Label(self.root, text="Bienvenido al Asistente Virtual", 
                                      font=("Times New Roman", 40, "bold", "underline"),
                                      bg="black",
                                      fg="white")
        self.label_welcome.pack(pady=20)

        # Instructions Label
        self.label_instructions = tk.Label(self.root, text="Estamos aqu� para ayudarle en lo que necesite. Elija una opci�n:", 
                                           font=("Times New Roman", 20),
                                           bg="black",
                                           fg="white")
        self.label_instructions.pack(pady=10)

        # Buttons
        self.button_estado = tk.Button(self.root, text="Consultar Estado de Pedido", 
                                       width=35, 
                                       font=("Times New Roman", 20),
                                       bg="black",
                                       fg="white",
                                       command=self.estado_de_pedido)
        self.button_estado.pack(pady=5)

        self.button_devoluciones = tk.Button(self.root, text="Informaci�n sobre Devoluciones y Reembolsos", 
                                             width=35, 
                                             font=("Times New Roman", 20),
                                             bg="black",
                                             fg="white",
                                             command=self.devoluciones_y_reembolsos)
        self.button_devoluciones.pack(pady=5)

        self.button_soporte = tk.Button(self.root, text="Soporte T�cnico", 
                                        width=35,
                                        font=("Times New Roman", 20),
                                        bg="black",
                                        fg="white", 
                                        command=self.soporte_tecnico)
        self.button_soporte.pack(pady=5)

        self.button_modificaciones = tk.Button(self.root, text="Modificar mi Cuenta", 
                                               width=35,
                                               font=("Times New Roman", 20),
                                               bg="black",
                                               fg="white", 
                                               command=self.modificaciones_en_cuenta)
        self.button_modificaciones.pack(pady=5)

        self.button_preguntas = tk.Button(self.root, text="Preguntas Frecuentes", 
                                          width=35,
                                          font=("Times New Roman", 20),
                                          bg="black",
                                          fg="white", 
                                          command=self.preguntas_frecuentes)
        self.button_preguntas.pack(pady=5)

        self.button_agente = tk.Button(self.root, text="Hablar con un Agente", 
                                       width=35,
                                       font=("Times New Roman", 20),
                                       bg="black",
                                       fg="white", 
                                       command=self.hablar_con_un_agente)
        self.button_agente.pack(pady=5)

        self.button_salir = tk.Button(self.root, text="Salir", 
                                      width=35, 
                                      font=("Times New Roman", 20),
                                      bg="white",
                                      fg="black",
                                      command=self.salir_atencion)
        self.button_salir.pack(pady=20)

    def salir_atencion(self):
        for widget in self.root.winfo_children():
            widget.destroy()
        self.root.destroy()
        self.main_program_class()

    def estado_de_pedido(self):
        def consultar_estado():
            pedido = entry_numero.get()
            respuesta = entry_respuesta.get().lower()
            if respuesta in ['s�', 'si']:
                frecuencia = entry_frecuencia.get().lower()
                messagebox.showinfo("Estado de Pedido", f"Buscando el estado de su pedido con el n�mero: {pedido}. "
                                                       f"Recibir� actualizaciones {frecuencia}.")
            else:
                messagebox.showinfo("Estado de Pedido", f"Buscando el estado de su pedido con el n�mero: {pedido}. "
                                                       f"Solo se enviar�n actualizaciones cuando haya cambios importantes.")
            ventana_estado.destroy()

        ventana_estado = tk.Toplevel(self.root)
        ventana_estado.title("Consultar Estado de Pedido")
        ventana_estado.geometry("1900x1000")
        ventana_estado.config(bg="black")

        label_numero = tk.Label(ventana_estado, text="Por favor, ingrese su n�mero de pedido:",
                                      font=("Times New Roman", 20),
                                      bg="black",
                                      fg="white")
        label_numero.pack(pady=10)

        entry_numero = tk.Entry(ventana_estado)
        entry_numero.pack(pady=10)

        label_respuesta = tk.Label(ventana_estado, text="�Le gustar�a recibir actualizaciones? (s�/no):",
                                   font=("Times New Roman", 20),
                                   bg="black",
                                   fg="white")
        label_respuesta.pack(pady=5)

        entry_respuesta = tk.Entry(ventana_estado)
        entry_respuesta.pack(pady=5)

        label_frecuencia = tk.Label(ventana_estado, text="�Prefiere actualizaciones diarias o cuando haya un cambio importante? (diarias/importante):",
                                    font=("Times New Roman", 20),
                                    bg="black",
                                    fg="white")
        label_frecuencia.pack(pady=5)

        entry_frecuencia = tk.Entry(ventana_estado)
        entry_frecuencia.pack(pady=5)

        button_consultar = tk.Button(ventana_estado, text="Consultar",
                                    font=("Times New Roman", 20),
                                    bg="black",
                                    fg="white",
                                    command=consultar_estado)
        button_consultar.pack(pady=20)

    def devoluciones_y_reembolsos(self):
        def procesar_devolucion():
            recibido = entry_recibido.get().lower()
            if recibido in ['s�', 'si']:
                estado_producto = entry_estado_producto.get()
                solucion = entry_solucion.get()
                confirmacion = entry_confirmacion.get().lower()
                if confirmacion in ['s�', 'si']:
                    messagebox.showinfo("Devoluciones y Reembolsos", f"Iniciaremos su solicitud de {solucion}. "
                                                               f"Le enviaremos la confirmaci�n a su correo.")
                else:
                    messagebox.showinfo("Devoluciones y Reembolsos", f"Iniciaremos su solicitud de {solucion}. "
                                                               f"No se enviar� confirmaci�n por correo.")
            else:
                messagebox.showinfo("Devoluciones y Reembolsos", "Entendido. Si tiene alguna otra consulta o necesita ayuda adicional, no dude en preguntar.")
            ventana_devolucion.destroy()

        ventana_devolucion = tk.Toplevel(self.root)
        ventana_devolucion.title("Devoluciones y Reembolsos")
        ventana_devolucion.geometry("1900x1000")
        ventana_devolucion.config(bg="black")

        label_recibido = tk.Label(ventana_devolucion, text="�Ha recibido el producto? (s�/no):",
                                  font=("Times New Roman", 20),
                                  bg="black",
                                  fg="white")
        label_recibido.pack(pady=5)

        entry_recibido = tk.Entry(ventana_devolucion)
        entry_recibido.pack(pady=5)

        label_estado_producto = tk.Label(ventana_devolucion, text="�En qu� estado se encuentra el producto? (nuevo/usado/danado):",
                                         font=("Times New Roman", 20),
                                         bg="black",
                                         fg="white")
        label_estado_producto.pack(pady=5)

        entry_estado_producto = tk.Entry(ventana_devolucion)
        entry_estado_producto.pack(pady=5)

        label_solucion = tk.Label(ventana_devolucion, text="�Prefiere reembolso o cambio de producto?",
                                  font=("Times New Roman", 20),
                                  bg="black",
                                  fg="white")
        label_solucion.pack(pady=5)

        entry_solucion = tk.Entry(ventana_devolucion)
        entry_solucion.pack(pady=5)

        label_confirmacion = tk.Label(ventana_devolucion, text="�Desea recibir confirmaci�n por correo electr�nico? (s�/no):",
                                      font=("Times New Roman", 20),
                                      bg="black",
                                      fg="white")
        label_confirmacion.pack(pady=5)

        entry_confirmacion = tk.Entry(ventana_devolucion)
        entry_confirmacion.pack(pady=5)

        button_devolucion = tk.Button(ventana_devolucion, text="Iniciar Devoluci�n",
                                      font=("Times New Roman", 20),
                                      bg="black",
                                      fg="white",
                                      command=procesar_devolucion)
        button_devolucion.pack(pady=20)

    def soporte_tecnico(self):
        def recibir_soporte():
            problema = entry_problema.get()
            reiniciar = entry_reiniciar.get().lower()
            if reiniciar in ['s�', 'si']:
                messagebox.showinfo("Soporte T�cnico", f"Problema recibido: {problema}. Si el problema persiste, intente restablecer la configuraci�n de f�brica.")
            else:
                messagebox.showinfo("Soporte T�cnico", f"Problema recibido: {problema}. Por favor, intente reiniciar su dispositivo.")
            ventana_soporte.destroy()

        ventana_soporte = tk.Toplevel(self.root)
        ventana_soporte.title("Soporte T�cnico")
        ventana_soporte.geometry("1900x1000")
        ventana_soporte.config(bg="black")

        label_problema = tk.Label(ventana_soporte, text="�Cu�l es el problema que est� experimentando?",
                                  font=("Times New Roman", 20),
                                  bg="black",
                                  fg="white")
        label_problema.pack(pady=10)

        entry_problema = tk.Entry(ventana_soporte)
        entry_problema.pack(pady=10)

        label_reiniciar = tk.Label(ventana_soporte, text="�Ha intentado reiniciar su dispositivo? (s�/no):",
                                  font=("Times New Roman", 20),
                                  bg="black",
                                  fg="white")
        label_reiniciar.pack(pady=5)

        entry_reiniciar = tk.Entry(ventana_soporte)
        entry_reiniciar.pack(pady=5)

        button_soporte = tk.Button(ventana_soporte, text="Recibir Soporte",
                                   font=("Arial", 14),
                                   command=recibir_soporte)
        button_soporte.pack(pady=20)

    def modificaciones_en_cuenta(self):
        def realizar_modificacion():
            seleccion = entry_modificacion.get()
            messagebox.showinfo("Modificar Cuenta", f"Ha seleccionado la opci�n: {seleccion}. Su solicitud ha sido procesada.")
            ventana_modificacion.destroy()

        ventana_modificacion = tk.Toplevel(self.root)
        ventana_modificacion.title("Modificar mi Cuenta")
        ventana_modificacion.geometry("1900x1000")
        ventana_modificacion.config(bg="black")

        label_modificaciones = tk.Label(ventana_modificacion, text="�Qu� desea modificar en su cuenta?",
                                  font=("Times New Roman", 20),
                                  bg="black",
                                  fg="white")
        label_modificaciones.pack(pady=10)

        opciones = ["Contrase�a", "Direcci�n", "Correo Electr�nico", "Desactivar Cuenta"]
        entry_modificacion = tk.StringVar()
        entry_modificacion.set(opciones[0])

        menu = tk.OptionMenu(ventana_modificacion, entry_modificacion, *opciones)
        menu.pack(pady=10)

        button_modificar = tk.Button(ventana_modificacion, text="Modificar", command=realizar_modificacion)
        button_modificar.pack(pady=20)

    def preguntas_frecuentes(self):
        def mostrar_respuesta():
            pregunta = entry_pregunta.get()
            respuestas = {
                "1": "Para realizar un pedido, selecciona el producto en nuestra tienda online y sigue los pasos.",
                "2": "Para cambiar o cancelar un pedido, debes hacerlo dentro de las primeras 24 horas.",
                "3": "Ofrecemos env�os a todas las ciudades, con opciones de entrega est�ndar y expr�s."
            }
            respuesta = respuestas.get(pregunta, "Lo siento, no entend� la pregunta. �Podr�as ser m�s espec�fico?")
            messagebox.showinfo("Preguntas Frecuentes", respuesta)
            ventana_preguntas.destroy()

        ventana_preguntas = tk.Toplevel(self.root)
        ventana_preguntas.title("Preguntas Frecuentes")
        ventana_preguntas.geometry("1900x1000")
        ventana_preguntas.config(bg="black")

        label_pregunta = tk.Label(ventana_preguntas, text="�En qu� puedo ayudarte?",
                                  font=("Times New Roman", 20),
                                  bg="black",
                                  fg="white")
        label_pregunta.pack(pady=10)

        entry_pregunta = tk.Entry(ventana_preguntas)
        entry_pregunta.pack(pady=10)

        button_responder = tk.Button(ventana_preguntas, text="Obtener Respuesta", command=mostrar_respuesta)
        button_responder.pack(pady=20)

    def hablar_con_un_agente(self):
        messagebox.showinfo("Hablar con un Agente", "Est�s en contacto con un agente. Tu solicitud ser� atendida pronto.")


if __name__ == "__main__":
    app = AsistenteVirtual()
    app.root.mainloop()