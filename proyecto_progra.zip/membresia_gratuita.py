#-- coding: iso-8859-15 --

import tkinter as tk
from tkinter import messagebox
import json
from Proyecto import Mostrar  # Import the `mostrar` class
from memb_pago import memb_pagada  # Import the `memb_pagada` class
from atencion_cliente import AsistenteVirtual

class MenuP:
    def __init__(self):
        # Ensure JSON file exists
        self.ensure_json_file()

        # Main window setup
        self.ventana_principal = tk.Tk()
        self.ventana_principal.title("Membres�a Gratuita")
        self.ventana_principal.geometry("1900x800")
        self.ventana_principal.config(bg="black")
        
        # Title Label
        self.titulo = tk.Label(self.ventana_principal, text="�Bienvenido al Menu Principal de Circlify!", 
                               font=("Times New Roman", 40, "bold", "underline"), 
                               bg="black", 
                               fg="white")
        self.titulo.pack(pady=20)

        # Buttons
        self.btn_descuentos = tk.Button(self.ventana_principal, text="Descuentos disponibles", 
                                        font=("Times New Roman", 20), 
                                        bg="gray", 
                                        fg="white", 
                                        command=self.ventana_descuentos,width=40)
        self.btn_descuentos.pack(pady=10)

        self.btn_buscar = tk.Button(self.ventana_principal, text="Buscar descuentos", 
                                    font=("Times New Roman", 20), 
                                    bg="gray", 
                                    fg="white", 
                                    command=self.ventana_buscar_descuento,width=40)
        self.btn_buscar.pack(pady=10)

        self.btn_tiendas = tk.Button(self.ventana_principal, text="Ver tiendas", 
                                            font=("Times New Roman", 20), 
                                            bg="gray", 
                                            fg="white", 
                                            command=self.mostrar_tiendas,width=40)
        self.btn_tiendas.pack(pady=10)

        self.btn_membresia = tk.Button(self.ventana_principal, text="Conoce los beneficios premium", 
                                       font=("Times New Roman", 20), 
                                       bg="gray", 
                                       fg="white", 
                                       command=self.mostrar_membresia,width=40)
        self.btn_membresia.pack(pady=10)

        self.btn_atencion = tk.Button(self.ventana_principal, text="Atencion al cliente", 
                                   font=("Times New Roman", 20), 
                                   bg="gray", 
                                   fg="white", 
                                   command=self.atencion_al_cliente,width=40)
        self.btn_atencion.pack(pady=10)

        self.btn_salir = tk.Button(self.ventana_principal, text="Salir", 
                                   font=("Times New Roman", 20), 
                                   bg="gray", 
                                   fg="white", 
                                   command=self.ventana_principal.quit,width=40)
        self.btn_salir.pack(pady=10)

        self.ventana_principal.mainloop()

    # Ensure the JSON file exists with default data
    def ensure_json_file(self):
        default_data = [
            {"nombre": "Tienda 1", "categoria": "Electr�nica", "descuento": "10%"},
            {"nombre": "Tienda 2", "categoria": "Ropa", "descuento": "15%"},
            {"nombre": "Tienda 3", "categoria": "Alimentos", "descuento": "5%"}
        ]
        try:
            with open('tiendas.json', 'r', encoding='utf-8') as file:
                # Check if the file is valid JSON
                json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            # If the file is missing or invalid, recreate it
            with open('tiendas.json', 'w', encoding='utf-8') as file:
                json.dump(default_data, file, ensure_ascii=False, indent=4)

    # Load shop data from JSON
    def load_shop_data(self):
        try:
            with open('tiendas.json', 'r', encoding='utf-8') as file:
                return json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            messagebox.showerror("Error", "No se puede cargar el archivo 'tiendas.json'.")
            return []

    # Function to display discounts
    # Function to display discounts with a scrollbar
    def ventana_descuentos(self):
        shops = self.load_shop_data()
        if not shops:
            return

        ventana = tk.Toplevel(self.ventana_principal)
        ventana.title("Descuentos Disponibles")
        ventana.geometry("1900x800")
        ventana.config(bg="black")

        lbl_titulo = tk.Label(ventana, text="Descuentos Disponibles", 
                              font=("Times New Roman", 20, "bold"), 
                              bg="white", 
                              fg="black")
        lbl_titulo.pack(pady=10)

        # Create a frame for the canvas and scrollbar
        frame = tk.Frame(ventana, bg="black")
        frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Add a canvas for scrolling
        canvas = tk.Canvas(frame, bg="black")
        canvas.pack(side="left", fill="both", expand=True)

        # Add a scrollbar to the canvas
        scrollbar = tk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        scrollbar.pack(side="right", fill="y")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Add a frame inside the canvas
        scrollable_frame = tk.Frame(canvas, bg="black")
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((450, 0), window=scrollable_frame, anchor="nw")

        # Display shop information in the scrollable frame
        for shop in shops:
            info = f"{shop['nombre']} ({shop['categoria']}): {shop['descuento']}"
            lbl_tienda = tk.Label(scrollable_frame, 
                                  text=info, 
                                  font=("Times New Roman", 16), 
                                  bg="black", 
                                  fg="white", 
                                  justify="left", 
                                  wraplength=350)
            lbl_tienda.pack(anchor="center", padx=20, pady=5)

        # Allow mouse scrolling
        def _on_mouse_wheel(event):
            canvas.yview_scroll(-1 * int(event.delta / 100), "units")

        canvas.bind_all("<MouseWheel>", _on_mouse_wheel)


    # Function to search for discounts
    def ventana_buscar_descuento(self):
        def realizar_busqueda():
            shops = self.load_shop_data()
            if not shops:
                return

            busqueda = entry_busqueda.get().lower()
            resultados = [shop for shop in shops if busqueda in shop['nombre'].lower() or busqueda in shop['categoria'].lower()]
            if resultados:
                resultado_texto = "\n".join([f"{r['nombre']} ({r['categoria']}): {r['descuento']}" for r in resultados])
            else:
                resultado_texto = "No se encontraron descuentos para tu b�squeda."
            lbl_resultado.config(text=resultado_texto)

        ventana = tk.Toplevel(self.ventana_principal)
        ventana.title("Buscar Descuentos")
        ventana.geometry("1900x800")
        ventana.config(bg="black")

        lbl_titulo = tk.Label(ventana, text="Buscar Descuentos", 
                              font=("Times New Roman", 50, "bold", "underline"), 
                              bg="black", 
                              fg="white")
        lbl_titulo.pack(pady=10)

        lbl_busqueda = tk.Label(ventana, text="Ingresa una tienda o categor�a:", 
                                font=("Times New Roman", 25), 
                                bg="black", 
                                fg="white")
        lbl_busqueda.pack(pady=5)

        entry_busqueda = tk.Entry(ventana, font=("Times New Roman", 20))
        entry_busqueda.pack(pady=5)

        btn_buscar = tk.Button(ventana, text="Buscar", 
                               font=("Times New Roman", 15), 
                               bg="black", 
                               fg="white", 
                               command=realizar_busqueda)
        btn_buscar.pack(pady=10)

        lbl_resultado = tk.Label(ventana, text="", 
                                 font=("Times New Roman", 15), 
                                 bg="black", 
                                 fg="white", 
                                 justify="left", 
                                 wraplength=350)
        lbl_resultado.pack(pady=10)

    def mostrar_tiendas(self):
        self.ventana_principal.destroy()
        Mostrar(MenuP)  

    def mostrar_membresia(self):
        self.ventana_principal.destroy()
        memb_pagada(MenuP)

    def atencion_al_cliente(self):
        self.ventana_principal.destroy()
        AsistenteVirtual(MenuP) 

# Example usage
if __name__ == "__main__":
    app = MenuP()
