from login import app
from membresia_gratuita import MenuP


    

# Instantiate and run the app
if __name__ == "__main__":
    application = app()
    application.ventana.mainloop()
    